package log;
public interface Login {
	public void login();
}
